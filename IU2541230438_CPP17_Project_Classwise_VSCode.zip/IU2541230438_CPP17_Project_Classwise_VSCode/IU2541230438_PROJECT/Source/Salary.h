#ifndef SALARY_H
#define SALARY_H
class Salary {
    double basic, deduction;
public:
    Salary();
    Salary(double basic, double deduction);
    double getBasic() const;
    double getDeduction() const;
    void set(double basic, double deduction);
    double netFrom(double allowances) const;
};
#endif
