#include "SalariedEmployee.h"
#include <sstream>
#include <iomanip>
SalariedEmployee::SalariedEmployee() : Employee(), salary(), allowance() {}
SalariedEmployee::SalariedEmployee(const std::string& i, const std::string& n, const std::string& d,
 double b, double h, double t, double m, double ded)
 : Employee(i,n,d), salary(b,ded), allowance(h,t,m) {}
double SalariedEmployee::calculateGrossSalary() const { return salary.getBasic() + allowance.total(); }
double SalariedEmployee::calculateNetSalary() const { return salary.netFrom(allowance.total()); }
std::string SalariedEmployee::getType() const { return "SalariedEmployee"; }
Employee* SalariedEmployee::clone() const { return new SalariedEmployee(*this); }
std::string SalariedEmployee::serialize() const {
 std::ostringstream o; o << std::quoted(id) << ' ' << std::quoted(name) << ' ' << std::quoted(department) << ' '
 << salary.getBasic() << ' ' << allowance.getHousing() << ' ' << allowance.getTransport() << ' '
 << allowance.getMedical() << ' ' << salary.getDeduction(); return o.str();
}
double SalariedEmployee::getBasic() const { return salary.getBasic(); }
double SalariedEmployee::getHousing() const { return allowance.getHousing(); }
double SalariedEmployee::getTransport() const { return allowance.getTransport(); }
double SalariedEmployee::getMedical() const { return allowance.getMedical(); }
double SalariedEmployee::getDeduction() const { return salary.getDeduction(); }
void SalariedEmployee::setPay(double b,double h,double t,double m,double d) { salary.set(b,d); allowance.set(h,t,m); }
