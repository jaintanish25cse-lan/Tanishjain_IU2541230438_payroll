#include "Employee.h"
Employee::Employee() : id(""), name(""), department("") {}
Employee::Employee(const std::string& i, const std::string& n, const std::string& d) : id(i), name(n), department(d) {}
Employee::~Employee() = default;
std::string Employee::getId() const { return id; }
std::string Employee::getName() const { return name; }
std::string Employee::getDepartment() const { return department; }
void Employee::setName(const std::string& value) { name = value; }
void Employee::setDepartment(const std::string& value) { department = value; }
