#ifndef FILEMANAGER_H
#define FILEMANAGER_H
#include <string>
class PayrollSystem;
class FileManager {
public:
    static bool save(const PayrollSystem& system, const std::string& filename);
    static bool load(PayrollSystem& system, const std::string& filename);
};
#endif
