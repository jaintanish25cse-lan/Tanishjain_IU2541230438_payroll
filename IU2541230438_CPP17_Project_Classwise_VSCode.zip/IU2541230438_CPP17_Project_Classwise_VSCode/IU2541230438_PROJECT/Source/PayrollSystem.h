#ifndef PAYROLLSYSTEM_H
#define PAYROLLSYSTEM_H
#include "Employee.h"
#include "SalariedEmployee.h"
#include <string>
class PayrollSystem {
    Employee** employees;
    int count, capacity;
    void resize();
    int findIndex(const std::string& id) const;
public:
    PayrollSystem();
    ~PayrollSystem();
    PayrollSystem(const PayrollSystem&) = delete;
    PayrollSystem& operator=(const PayrollSystem&) = delete;
    int size() const;
    const Employee* at(int index) const;
    Employee* at(int index);
    bool add(Employee* employee);
    bool update(const std::string& id, const std::string& name, const std::string& department,
                double basic, double housing, double transport, double medical, double deduction);
    bool remove(const std::string& id);
    int search(const std::string& id) const;
    void displayAll() const;
    void processPayroll() const;
    void report() const;
    void clear();
    bool replaceFromFile(Employee** loaded, int loadedCount);
};
#endif
