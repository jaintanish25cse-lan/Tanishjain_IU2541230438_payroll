#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include <string>

class Employee {
protected:
    std::string id, name, department;
public:
    Employee();
    Employee(const std::string& id, const std::string& name, const std::string& department);
    virtual ~Employee();
    std::string getId() const;
    std::string getName() const;
    std::string getDepartment() const;
    void setName(const std::string& value);
    void setDepartment(const std::string& value);
    virtual double calculateGrossSalary() const = 0;
    virtual std::string getType() const = 0;
    virtual Employee* clone() const = 0;
    virtual std::string serialize() const = 0;
};
#endif
