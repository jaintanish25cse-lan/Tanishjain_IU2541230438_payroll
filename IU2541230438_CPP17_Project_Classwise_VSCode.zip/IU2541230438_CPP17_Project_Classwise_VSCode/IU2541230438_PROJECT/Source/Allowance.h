#ifndef ALLOWANCE_H
#define ALLOWANCE_H
class Allowance {
    double housing, transport, medical;
public:
    Allowance();
    Allowance(double housing, double transport, double medical);
    double total() const;
    double getHousing() const;
    double getTransport() const;
    double getMedical() const;
    void set(double housing, double transport, double medical);
};
#endif
