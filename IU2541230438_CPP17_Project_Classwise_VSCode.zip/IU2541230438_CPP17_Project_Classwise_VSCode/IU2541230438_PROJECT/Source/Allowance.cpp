#include "Allowance.h"
Allowance::Allowance() : housing(0), transport(0), medical(0) {}
Allowance::Allowance(double h, double t, double m) : housing(h), transport(t), medical(m) {}
double Allowance::total() const { return housing + transport + medical; }
double Allowance::getHousing() const { return housing; }
double Allowance::getTransport() const { return transport; }
double Allowance::getMedical() const { return medical; }
void Allowance::set(double h, double t, double m) { housing=h; transport=t; medical=m; }
