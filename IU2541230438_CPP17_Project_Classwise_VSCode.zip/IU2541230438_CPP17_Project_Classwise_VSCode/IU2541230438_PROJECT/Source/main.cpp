#include "PayrollSystem.h"
#include "FileManager.h"
#include "SalariedEmployee.h"
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <filesystem>

const std::string DATA_FILE = "Data/employees.txt";

std::string readText(const std::string& prompt) {
    std::string value;
    std::cout << prompt;
    std::getline(std::cin, value);
    if (value.find('|') != std::string::npos) throw std::invalid_argument("The | character is not allowed.");
    return value;
}
double readMoney(const std::string& prompt) {
    std::string line; std::cout << prompt; std::getline(std::cin,line);
    std::size_t used=0; double value=std::stod(line,&used);
    if(used!=line.size() || value<0) throw std::invalid_argument("Enter a valid non-negative number.");
    return value;
}
void addEmployee(PayrollSystem& system) {
    try {
        std::string id=readText("Employee ID: ");
        std::string name=readText("Full name: ");
        std::string dept=readText("Department: ");
        if(id.empty()||name.empty()||dept.empty()) { std::cout<<"ID, name and department cannot be empty.\n"; return; }
        double basic=readMoney("Basic salary: ");
        double housing=readMoney("Housing allowance: ");
        double transport=readMoney("Transport allowance: ");
        double medical=readMoney("Medical allowance: ");
        double deduction=readMoney("Deduction: ");
        if(deduction>basic+housing+transport+medical) { std::cout<<"Deduction cannot exceed gross salary.\n"; return; }
        if(system.add(new SalariedEmployee(id,name,dept,basic,housing,transport,medical,deduction)))
            std::cout<<"Employee added successfully.\n";
        else { std::cout<<"Could not add employee. Check for a duplicate ID.\n"; }
    } catch(const std::exception& e) { std::cout<<"Input error: "<<e.what()<<"\n"; }
}
void updateEmployee(PayrollSystem& system) {
    try {
        std::string id=readText("Enter employee ID to update: ");
        if(system.search(id)<0) { std::cout<<"Employee not found.\n"; return; }
        std::string name=readText("New full name: ");
        std::string dept=readText("New department: ");
        double b=readMoney("New basic salary: "), h=readMoney("Housing allowance: ");
        double t=readMoney("Transport allowance: "), m=readMoney("Medical allowance: "), d=readMoney("Deduction: ");
        if(name.empty()||dept.empty()||d>b+h+t+m) { std::cout<<"Invalid name, department or deduction.\n"; return; }
        std::cout<<(system.update(id,name,dept,b,h,t,m,d)?"Record updated.\n":"Update failed.\n");
    } catch(const std::exception& e) { std::cout<<"Input error: "<<e.what()<<"\n"; }
}
int main() {
    PayrollSystem system;
    try {
        std::filesystem::create_directories("Data");
        if(FileManager::load(system,DATA_FILE)) std::cout<<"Loaded "<<system.size()<<" employee record(s).\n";
        else std::cout<<"No saved data found; starting with an empty payroll.\n";
    } catch(const std::exception& e) { std::cout<<"Startup note: "<<e.what()<<"\n"; }
    bool running=true;
    while(running) {
        std::cout<<"\n===== PAYROLL MANAGEMENT SYSTEM =====\n"
          "1. Add Record\n2. Display Records\n3. Search Record\n4. Update Record\n"
          "5. Delete Record\n6. Process Payroll / Print Payslip\n7. Report\n8. Save/Load\n9. Exit\nChoose an option: ";
        std::string choice; std::getline(std::cin,choice);
        try {
            if(choice=="1") addEmployee(system);
            else if(choice=="2") system.displayAll();
            else if(choice=="3") {
                std::string id=readText("Enter employee ID: "); int i=system.search(id);
                if(i<0) std::cout<<"Employee not found.\n";
                else { auto* e=dynamic_cast<SalariedEmployee*>(system.at(i)); if(e) { std::cout<<"Found: "<<e->getName()<<" | "<<e->getDepartment()<<"\n"; } }
            } else if(choice=="4") updateEmployee(system);
            else if(choice=="5") {
                std::string id=readText("Enter employee ID to delete: ");
                std::cout<<(system.remove(id)?"Employee deleted.\n":"Employee not found.\n");
            } else if(choice=="6") system.processPayroll();
            else if(choice=="7") system.report();
            else if(choice=="8") {
                std::cout<<"1. Save records\n2. Reload records\nChoose: ";
                std::string sub; std::getline(std::cin,sub);
                if(sub=="1") std::cout<<(FileManager::save(system,DATA_FILE)?"Records saved.\n":"Save failed.\n");
                else if(sub=="2") std::cout<<(FileManager::load(system,DATA_FILE)?"Records loaded.\n":"Load failed; file may not exist.\n");
                else std::cout<<"Invalid save/load choice.\n";
            } else if(choice=="9") {
                std::cout<<(FileManager::save(system,DATA_FILE)?"Data saved. ":"Warning: data could not be saved. ");
                std::cout<<"Goodbye!\n"; running=false;
            } else std::cout<<"Invalid choice. Enter 1-9.\n";
        } catch(const std::exception& e) { std::cout<<"Error: "<<e.what()<<"\n"; }
    }
    return 0;
}
