#include "FileManager.h"
#include "PayrollSystem.h"
#include "SalariedEmployee.h"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <vector>
bool FileManager::save(const PayrollSystem& system,const std::string& filename) {
 std::ofstream out(filename);
 if(!out) return false;
 out<<"# Payroll Management System data v1\n";
 for(int i=0;i<system.size();++i) {
  auto* e=dynamic_cast<const SalariedEmployee*>(system.at(i));
  if(e) out<<e->serialize()<<"\n";
 }
 return static_cast<bool>(out);
}
bool FileManager::load(PayrollSystem& system,const std::string& filename) {
 std::ifstream in(filename);
 if(!in) return false;
 std::vector<Employee*> loaded;
 std::string line;
 while(std::getline(in,line)) {
  if(line.empty() || line[0]=='#') continue;
  std::istringstream input(line);
  std::string id,name,dept; double b,h,t,m,d;
  if(input>>std::quoted(id)>>std::quoted(name)>>std::quoted(dept)>>b>>h>>t>>m>>d) {
   if(b>=0 && h>=0 && t>=0 && m>=0 && d>=0) {
    bool duplicate=false; for(auto* x:loaded) if(x->getId()==id) duplicate=true;
    if(!duplicate) loaded.push_back(new SalariedEmployee(id,name,dept,b,h,t,m,d));
   }
  }
 }
 Employee** arr=new Employee*[loaded.size()];
 for(std::size_t i=0;i<loaded.size();++i) arr[i]=loaded[i];
 system.replaceFromFile(arr,static_cast<int>(loaded.size()));
 delete[] arr;
 return true;
}
