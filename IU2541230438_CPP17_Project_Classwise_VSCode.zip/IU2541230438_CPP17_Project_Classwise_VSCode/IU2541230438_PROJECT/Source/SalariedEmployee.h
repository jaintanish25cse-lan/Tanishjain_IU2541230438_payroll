#ifndef SALARIEDEMPLOYEE_H
#define SALARIEDEMPLOYEE_H
#include "Employee.h"
#include "Salary.h"
#include "Allowance.h"
class SalariedEmployee : public Employee {
    Salary salary;
    Allowance allowance;
public:
    SalariedEmployee();
    SalariedEmployee(const std::string& id, const std::string& name, const std::string& department,
                     double basic, double housing, double transport, double medical, double deduction);
    double calculateGrossSalary() const override;
    double calculateNetSalary() const;
    std::string getType() const override;
    Employee* clone() const override;
    std::string serialize() const override;
    double getBasic() const;
    double getHousing() const;
    double getTransport() const;
    double getMedical() const;
    double getDeduction() const;
    void setPay(double basic, double housing, double transport, double medical, double deduction);
};
#endif
