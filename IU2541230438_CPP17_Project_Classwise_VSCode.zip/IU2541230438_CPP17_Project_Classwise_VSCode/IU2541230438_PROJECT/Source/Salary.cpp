#include "Salary.h"
Salary::Salary() : basic(0), deduction(0) {}
Salary::Salary(double b, double d) : basic(b), deduction(d) {}
double Salary::getBasic() const { return basic; }
double Salary::getDeduction() const { return deduction; }
void Salary::set(double b, double d) { basic=b; deduction=d; }
double Salary::netFrom(double allowances) const { return basic + allowances - deduction; }
