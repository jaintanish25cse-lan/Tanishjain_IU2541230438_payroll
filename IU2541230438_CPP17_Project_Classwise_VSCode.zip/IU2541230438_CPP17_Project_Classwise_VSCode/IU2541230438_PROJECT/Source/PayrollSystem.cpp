#include "PayrollSystem.h"
#include "Payslip.h"
#include <iostream>
#include <iomanip>
#include <limits>
PayrollSystem::PayrollSystem() : employees(new Employee*[5]), count(0), capacity(5) {
 for (int i=0;i<capacity;++i) employees[i]=nullptr;
}
PayrollSystem::~PayrollSystem() {
 clear(); delete[] employees;
}
void PayrollSystem::clear() {
 for (int i=0;i<count;++i) { delete employees[i]; employees[i]=nullptr; }
 count=0;
}
void PayrollSystem::resize() {
 int next=capacity*2; Employee** temp=new Employee*[next];
 for(int i=0;i<next;++i) temp[i]=nullptr;
 for(int i=0;i<count;++i) temp[i]=employees[i];
 delete[] employees; employees=temp; capacity=next;
}
int PayrollSystem::size() const { return count; }
const Employee* PayrollSystem::at(int i) const { return (i>=0 && i<count)?employees[i]:nullptr; }
Employee* PayrollSystem::at(int i) { return (i>=0 && i<count)?employees[i]:nullptr; }
int PayrollSystem::findIndex(const std::string& id) const {
 for(int i=0;i<count;++i) if(employees[i]->getId()==id) return i;
 return -1;
}
int PayrollSystem::search(const std::string& id) const { return findIndex(id); }
bool PayrollSystem::add(Employee* e) {
 if(!e || e->getId().empty() || findIndex(e->getId())>=0) return false;
 if(count==capacity) resize();
 employees[count++]=e; return true;
}
bool PayrollSystem::update(const std::string& id,const std::string& n,const std::string& d,
 double b,double h,double t,double m,double ded) {
 int i=findIndex(id); if(i<0) return false;
 auto* e=dynamic_cast<SalariedEmployee*>(employees[i]); if(!e) return false;
 e->setName(n); e->setDepartment(d); e->setPay(b,h,t,m,ded); return true;
}
bool PayrollSystem::remove(const std::string& id) {
 int i=findIndex(id); if(i<0) return false;
 delete employees[i];
 for(int j=i;j<count-1;++j) employees[j]=employees[j+1];
 employees[--count]=nullptr; return true;
}
void PayrollSystem::displayAll() const {
 if(count==0) { std::cout<<"No employee records found.\n"; return; }
 std::cout<<std::fixed<<std::setprecision(2);
 std::cout<<"\n"<<std::left<<std::setw(12)<<"ID"<<std::setw(22)<<"Name"<<std::setw(18)<<"Department"<<std::right<<std::setw(14)<<"Gross"<<std::setw(14)<<"Net"<<"\n";
 std::cout<<std::string(80,'-')<<"\n";
 for(int i=0;i<count;++i) {
  auto* e=dynamic_cast<const SalariedEmployee*>(employees[i]);
  if(e) std::cout<<std::left<<std::setw(12)<<e->getId()<<std::setw(22)<<e->getName().substr(0,21)<<std::setw(18)<<e->getDepartment().substr(0,17)<<std::right<<std::setw(14)<<e->calculateGrossSalary()<<std::setw(14)<<e->calculateNetSalary()<<"\n";
 }
}
void PayrollSystem::processPayroll() const {
 std::string id; std::cout<<"Enter employee ID for payslip: "; std::getline(std::cin,id);
 int i=findIndex(id); if(i<0) { std::cout<<"Employee not found.\n"; return; }
 auto* e=dynamic_cast<const SalariedEmployee*>(employees[i]);
 if(e) Payslip::print(*e);
}
void PayrollSystem::report() const {
 double gross=0, net=0;
 for(int i=0;i<count;++i) { auto* e=dynamic_cast<const SalariedEmployee*>(employees[i]); if(e){gross+=e->calculateGrossSalary(); net+=e->calculateNetSalary();}}
 std::cout<<std::fixed<<std::setprecision(2)<<"\n===== PAYROLL SUMMARY =====\nEmployees: "<<count<<"\nTotal Gross Payroll: "<<gross<<"\nTotal Net Payroll  : "<<net<<"\n===========================\n";
}
bool PayrollSystem::replaceFromFile(Employee** loaded,int n) {
 clear();
 while(count+n>capacity) resize();
 for(int i=0;i<n;++i) { employees[count++]=loaded[i]; loaded[i]=nullptr; }
 return true;
}
