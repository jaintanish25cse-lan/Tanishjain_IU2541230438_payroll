#include "Payslip.h"
#include <iostream>
#include <iomanip>
void Payslip::print(const SalariedEmployee& e) {
 std::cout << "\n========== PAYSLIP ==========\n"
 << "Employee ID : " << e.getId() << "\nName        : " << e.getName()
 << "\nDepartment  : " << e.getDepartment() << "\nBasic Salary: " << std::fixed << std::setprecision(2) << e.getBasic()
 << "\nHousing     : " << e.getHousing() << "\nTransport   : " << e.getTransport()
 << "\nMedical     : " << e.getMedical() << "\nGross Salary: " << e.calculateGrossSalary()
 << "\nDeduction   : " << e.getDeduction() << "\nNet Salary  : " << e.calculateNetSalary()
 << "\n=============================\n";
}
