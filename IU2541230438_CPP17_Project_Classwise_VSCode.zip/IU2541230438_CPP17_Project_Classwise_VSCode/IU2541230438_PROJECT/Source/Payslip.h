#ifndef PAYSLIP_H
#define PAYSLIP_H
#include "SalariedEmployee.h"
class Payslip {
public:
    static void print(const SalariedEmployee& employee);
};
#endif
