PAYROLL MANAGEMENT SYSTEM — C++17
Enrollment Number: IU2541230438
Project Code: CPP17
IDE: Visual Studio Code

REFERENCE
The attached book “C++: The Complete Reference” is used as a learning reference for standard C++ classes/objects, constructors and destructors, inheritance, virtual functions/runtime polymorphism, dynamic allocation, exceptions, and file I/O. The project code is organized for this assigned Payroll Management System; it is not a copied book example.

CLASS-WISE SOURCE FILES
Every major class has its own header (.h) and implementation (.cpp) file wherever applicable:
- Employee.h / Employee.cpp: abstract base class and common employee details.
- SalariedEmployee.h / SalariedEmployee.cpp: derived employee type; salary calculation and polymorphic overrides.
- Salary.h / Salary.cpp: basic salary and deductions.
- Allowance.h / Allowance.cpp: housing, transport, and medical allowances.
- Payslip.h / Payslip.cpp: formatted payslip output.
- PayrollSystem.h / PayrollSystem.cpp: employee collection and payroll operations.
- FileManager.h / FileManager.cpp: saving/loading records.
- main.cpp: menu, input handling, and calls to PayrollSystem; business logic is kept in the classes.

PROJECT FOLDER MAP
Source/      All class-wise .h/.cpp files and main.cpp
Data/        Saved employee data (employees.txt)
Diagrams/    Use Case, Class, and two Sequence diagrams (PNG + editable DOT files)
Executable/  Includes environment test build; create Windows Project.exe using build.bat
Screenshots/ Demonstration output (replace/add your own screenshots after running in VS Code)
.vscode/     VS Code build task
build.bat    Windows build script
ProjectReport.pdf and Project_Report_Template.docx
Submission_Template.docx
TEST_RESULTS.txt

BUILD IN VS CODE ON WINDOWS
1. Install MinGW-w64 (or another g++ toolchain) and ensure g++ is in PATH.
2. Open the extracted IU2541230438_PROJECT folder in VS Code (File > Open Folder).
3. Select Terminal > Run Build Task > Build Payroll Management System, or run build.bat in the integrated terminal.
4. Run Executable\Project.exe from the project root directory. The program uses the relative path Data\employees.txt.
5. Test add, display, search, update, delete, payslip, report, save/load, and exit. Close and reopen the program to verify persistence.

MANUAL BUILD COMMAND (PowerShell, from project root)
g++ -std=c++17 -Wall -Wextra -pedantic Source/main.cpp Source/Employee.cpp Source/Salary.cpp Source/Allowance.cpp Source/SalariedEmployee.cpp Source/Payslip.cpp Source/PayrollSystem.cpp Source/FileManager.cpp -o Executable/Project.exe

PAYROLL FORMULAS
Gross Salary = Basic Salary + Housing Allowance + Transport Allowance + Medical Allowance
Net Salary = Gross Salary - Deduction

OOP CONCEPTS USED
- Encapsulation: Salary and Allowance keep pay data private and expose methods.
- Constructors/destructors: objects initialize state and release owned resources.
- Inheritance: SalariedEmployee derives from Employee.
- Runtime polymorphism: Employee declares virtual functions overridden by SalariedEmployee.
- Dynamic memory: PayrollSystem owns a dynamically allocated array of Employee pointers and deletes owned objects.
- Exception/input validation: invalid numeric input and invalid records are handled.
- File handling: FileManager persists employee records in Data/employees.txt.

IMPORTANT BEFORE SUBMISSION
The included Executable/PayrollSystem is a Linux test build, not a Windows .exe. Compile Project.exe on your Windows computer using build.bat. Run and verify the complete program, capture genuine screenshots, ensure your GitHub repository URL is entered in the report, and complete the submission checklist. Do not claim the sample demonstration screenshot is a screenshot from your own Windows run.
