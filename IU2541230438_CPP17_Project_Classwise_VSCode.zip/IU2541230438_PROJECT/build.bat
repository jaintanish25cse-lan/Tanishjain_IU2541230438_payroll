@echo off
setlocal
if not exist Executable mkdir Executable
g++ -std=c++17 -Wall -Wextra -pedantic Source\main.cpp Source\Employee.cpp Source\Salary.cpp Source\Allowance.cpp Source\SalariedEmployee.cpp Source\Payslip.cpp Source\PayrollSystem.cpp Source\FileManager.cpp -o Executable\Project.exe
if errorlevel 1 (
  echo Build failed. Check that MinGW-w64 g++ is installed and on PATH.
  exit /b 1
)
echo Build successful: Executable\Project.exe
echo Run it from the project root folder.
